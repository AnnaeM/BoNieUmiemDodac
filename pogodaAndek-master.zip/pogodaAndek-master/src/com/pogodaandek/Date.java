package com.pogodaandek;

public class Date {
	public String epoch;
	// public String prettyShort; //nie wiem sk�d mi si� to wzi�o, nigdzie w
	// odpowiedzi tego nie widz�
	public String pretty;
	public String day;
	public String weekDay; // dzie� tygodnia s�ownie
	public String weekDayShort;
	public String month;
	public String monthName;
	public String year;
	public String yday;
	public String hour;
	public String min;
	public String ampm;
	public String tzShort;
	public String tzLong;
}
