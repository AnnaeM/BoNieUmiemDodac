package com.pogodaandek;

import android.text.format.Time;

public class Astronomy {
	public String percentIlluminated; // ile procent ksi�yca si� �wieci?
	public String ageOfMoon; // wiek ksi�yca-ilo�� dni po nowiu
	public String phaseofMoon; // faza ksi�yca
	// NIE mam poj�cia w jakiej klasie mo�na przechowywa� godz i min wschodow i
	// zachod�w :(
	public Time moonrise; // wsch�d ksi�yca
	public Time moonset; // zach�d s�o�ca
	public Time sunrise; // wsch�d s�o�ca
	public Time sunset; // zach�d s�o�ca

}
